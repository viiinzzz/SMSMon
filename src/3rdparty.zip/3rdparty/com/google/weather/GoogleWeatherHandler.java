package com.google.weather;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class GoogleWeatherHandler extends DefaultHandler {
    private WeatherSet weatherSet = null;

    private boolean inForecastInformation = false;
    private boolean inCurrentConditions = false;
    private boolean inForecastConditions = false;

    public WeatherSet getWeatherSet() {
        return weatherSet;
    }

    public void startElement(String uri, String localName, String qName,
            Attributes attributes) throws SAXException {
        if(qName.equals("xml_api_reply") || qName.equals("weather")) {
            return;
        }
        if(qName.equals("forecast_information")){
            weatherSet = new WeatherSet();
            inForecastInformation = true;
            return;
        }

        if(qName.equals("current_conditions")){
            WeatherCurrentCondition todayCondition = new WeatherCurrentCondition();
            weatherSet.setCurrentCondition(todayCondition);
            inCurrentConditions = true;
            return;
        }

        if(qName.equals("forecast_conditions")){
            WeatherForecastCondition forecastCondition = new WeatherForecastCondition();
            weatherSet.getForecastConditions().add(forecastCondition);
            inForecastConditions = true;
            return;
        }

        String dataAttr = attributes.getValue("data");

        if(inForecastInformation) {
            if(qName.equals("city")){
                weatherSet.setCity(dataAttr);
            } else if(qName.equals("postal_code")){
                weatherSet.setPostalCode(dataAttr);
            } else if(qName.equals("latitude_e6")){
                weatherSet.setLatitude(dataAttr);
            } else if(qName.equals("longitude_e6")) {
                weatherSet.setLongitude(dataAttr);
            } else if(qName.equals("forecast_date")){
                weatherSet.setForecastDate(dataAttr);
            } else if(qName.equals("current_date_time")){
                weatherSet.setCurrentDate(dataAttr);
            } else if(qName.equals("unit_system")){
                weatherSet.setUnitSystem(dataAttr);
            }
            return;
        }

        if(qName.equals("condition")) {
            if(inCurrentConditions) {
                weatherSet.getCurrentCondition().setCondition(dataAttr);
            } else {
                weatherSet.getLastForecastCondition().setCondition(dataAttr);
            }
        } else if(qName.equals("temp_f")) {
            weatherSet.getCurrentCondition().setTempFahrenheit(dataAttr);
        } else if(qName.equals("temp_c")){
            weatherSet.getCurrentCondition().setTempCelcius(dataAttr);
        } else if(qName.equals("humidity")){
            weatherSet.getCurrentCondition().setHumidity(dataAttr);
        } else if(qName.equals("icon")){
            if(inCurrentConditions) {
                weatherSet.getCurrentCondition().setIcon(dataAttr);
            } else {
                weatherSet.getLastForecastCondition().setIcon(dataAttr);
            }
        } else if(qName.equals("wind_condition")){
            weatherSet.getCurrentCondition().setWindCondition(dataAttr);
        } else if(qName.equals("day_of_week")) {
            weatherSet.getLastForecastCondition().setDayOfWeek(dataAttr);
        } else if(qName.equals("low")) {
            weatherSet.getLastForecastCondition().setLow(dataAttr);
        } else if(qName.equals("high")) {
            weatherSet.getLastForecastCondition().setHigh(dataAttr);
        }
    }

    @Override
    public void endElement(String uri, String localName, String name)
            throws SAXException {
        if(name.equals("forecast_information")){
            inForecastInformation = false;
            return;
        }

        if(name.equals("current_conditions")){
            inCurrentConditions = false;
            return;
        }

        if(name.equals("forecast_conditions")){
            inForecastConditions = false;
            return;
        }
    }
}