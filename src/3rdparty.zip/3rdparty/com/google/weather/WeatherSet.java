package com.google.weather;

import java.util.ArrayList;
import java.util.List;

public class WeatherSet {
    private String city;

    private String postalCode;

    private String latitude;

    private String longitude;

    private String forecastDate;

    private String currentDate;

    private String unitSystem;

    private WeatherCurrentCondition currentCondition;

    private List<WeatherForecastCondition> forecastConditions;

    public WeatherSet() {
        forecastConditions = new ArrayList<WeatherForecastCondition>();
    }

    public WeatherForecastCondition getLastForecastCondition() {
        return forecastConditions.get(forecastConditions.size() - 1);
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getForecastDate() {
        return forecastDate;
    }

    public void setForecastDate(String forecastDate) {
        this.forecastDate = forecastDate;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    public String getUnitSystem() {
        return unitSystem;
    }

    public void setUnitSystem(String unitSystem) {
        this.unitSystem = unitSystem;
    }

    public WeatherCurrentCondition getCurrentCondition() {
        return currentCondition;
    }

    public void setCurrentCondition(WeatherCurrentCondition currentCondition) {
        this.currentCondition = currentCondition;
    }

    public List<WeatherForecastCondition> getForecastConditions() {
        return forecastConditions;
    }

    public void setForeastConditions(
            List<WeatherForecastCondition> foreastConditions) {
        this.forecastConditions = foreastConditions;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("<city data=" +  this.city + "/>\n");

        sb.append("<postal_code data=" +this.postalCode+"/>\n");
        sb.append("<latitude_e6 data=" +this.latitude+"/>\n");
        sb.append("<longitude_e6 data="+this.longitude+"/>\n");
        sb.append("<forecast_date data="+this.forecastDate+"/>\n");
        sb.append("<current_date_time data="+this.currentDate+"/>\n");
        sb.append("<unit_system data="+this.unitSystem+"/>\n");

        sb.append("\n\n" + this.currentCondition + "\n\n");
        sb.append(this.forecastConditions);

        return sb.toString();
    }

    
    public static float f2c(int f) {
        return (f - 32) * (5f / 9);
    }

    public static String F2C(String F) {
        try {
            int f = Integer.parseInt(F);
            float c = f2c(f);
            return Math.round(c * 10) / 10 + "";
        } catch(Exception e) {return "?";}
    }

    public String getForecastText() {
        StringBuffer ret = new StringBuffer();
        java.util.ListIterator<WeatherForecastCondition> i = getForecastConditions().listIterator();
        while (i.hasNext()) {
            WeatherForecastCondition forecast = i.next();
            ret.append(": " + forecast.getDayOfWeek() + "=" + forecast.getCondition());
            ret.append(" " + F2C(forecast.getLow()) + "-" + F2C(forecast.getHigh()) + "deg.C ");
        } return ret.toString();
    }
}