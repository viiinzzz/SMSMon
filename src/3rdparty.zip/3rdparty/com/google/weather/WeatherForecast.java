package com.google.weather;

import java.io.IOException;
import java.io.InputStream;
import java.net.*;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

public class WeatherForecast {
    public final static String WEATHER_URL =
        "http://www.google.com/ig/api?weather=%s";

    public static WeatherSet parse(String city) {
        city = city.replace(" ", "%20");
        String weatherURL = String.format(WEATHER_URL, city);
        try {
                URL url = new URL(weatherURL);
                URLConnection con = url.openConnection();
                InputStream in = con.getInputStream();
                return parse(in, city);
        } catch (Exception e) {
            System.out.println("WeatherForecast " + city + ": invalid data downloaded from " + WEATHER_URL);
            return null;
        }
        
    }

    public static WeatherSet parse(String fileName, String city) {
        InputStream in = WeatherForecast.class.getResourceAsStream(fileName);
        return parse(in, city);
    }

    public static WeatherSet parse(InputStream in, String city) {
        String s = null; if(in != null) try {
            byte buf[] = new byte[in.available()];
            if (in.read(buf) != buf.length) throw new Exception();
            s = new String(buf, "ISO-8859-1")
                    .replace("<?xml version=\"1.0\"?>", "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>")
                    .replaceAll("><", ">\n<");
            //System.out.println("\n\n" + s);
        } catch(Exception e) {
            System.out.println("WeatherForecast " + city + ": " + e.getMessage());
        } finally {
            if (s == null) return null;
        }

        SAXParserFactory spf = SAXParserFactory.newInstance(); try {
            SAXParser parser = spf.newSAXParser();
            XMLReader reader = parser.getXMLReader();
            GoogleWeatherHandler handler = new GoogleWeatherHandler();
            reader.setContentHandler(handler);
            reader.parse(new InputSource(new java.io.StringReader(s)));
            return handler.getWeatherSet();
        } catch (Exception e) {
            System.out.println("WeatherForecast " + city + ": " + e.getMessage());
            return null;
        }
        
    }


    public static void main(String[] args) {
//        String[] cities = {"PARIS", "ORLEANS", "MILAN", "MADRID"};
        String[] cities = {"PARIS"};
        for(int i = 0; i < cities.length; i++) {
            String city = cities[i];
            WeatherForecast weather = new WeatherForecast();
            WeatherSet weatherSet = weather.parse(city);
            
            if (weatherSet != null) {
                String temp = weatherSet.getCurrentCondition().getTempCelcius();
                java.net.URL iconURL = null; try {
                    iconURL = new java.net.URL("http://www.google.com"
                            + weatherSet.getCurrentCondition().getIcon());
                } catch(Exception e) {}
                //System.out.println(city + ": " + temp + "°C\n" + iconURL);
                //System.out.println(city + ": " + weatherSet.getCurrentCondition());
                System.out.println(city + weatherSet.getForecastText());
            } else System.out.println(city + ": no data available.");
        }
    }
}