package com.google.weather;

public class WeatherCurrentCondition extends WeatherCondition {
    private String tempFahrenheit;

    private String tempCelcius;

    private String humidity;

    private String icon;

    private String windCondition;

    public String getTempFahrenheit() {
        return tempFahrenheit;
    }

    public void setTempFahrenheit(String tempFahrenheit) {
        this.tempFahrenheit = tempFahrenheit;
    }

    public String getTempCelcius() {
        return tempCelcius;
    }

    public void setTempCelcius(String tempCelcius) {
        this.tempCelcius = tempCelcius;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getWindCondition() {
        return windCondition;
    }

    public void setWindCondition(String windCondition) {
        this.windCondition = windCondition;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("<condition data=" + super.getCondition() + "/>\n");
        sb.append("<temp_f data=" + this.tempFahrenheit + "/>\n");
        sb.append("<temp_c data=" + this.tempFahrenheit + "/>\n");
        sb.append("<humidity data=humidity：" + this.humidity + "12%/>\n");
        sb.append("<icon data=" + super.getIcon() +"/>\n");
        sb.append("<wind_condition data=" + this.windCondition +"/>\n");
        return sb.toString();
    }
}