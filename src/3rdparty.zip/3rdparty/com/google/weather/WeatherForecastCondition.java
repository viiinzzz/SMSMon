package com.google.weather;

public class WeatherForecastCondition extends WeatherCondition {
    private String low;

    private String high;

    private String dayOfWeek;

    public String getLow() {
        return low;
    }

    public void setLow(String low) {
        this.low = low;
    }

    public String getHigh() {
        return high;
    }

    public void setHigh(String high) {
        this.high = high;
    }


    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("\t<day_of_week data=" + this.dayOfWeek +"/>\n");
        sb.append("\t<low data=" + this.low+"/>\n");
        sb.append("\t<high data=" + this.high+"/>\n");
        sb.append("\t<icon data=" +super.getIcon()+"/>\n");
        sb.append("\t<condition data=" +super.getCondition()+"/>\n");
        return sb.toString();
    }
}